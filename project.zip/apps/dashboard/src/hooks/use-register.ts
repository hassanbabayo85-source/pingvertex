"use client";

import { useMutation } from "@tanstack/react-query";
import { register } from "@/lib/auth-api";

export function useRegister() {
  return useMutation({
    mutationFn: register,
  });
}
