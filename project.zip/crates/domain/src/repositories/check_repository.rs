use std::error::Error;

use async_trait::async_trait;

use crate::shared::ids::{CheckId, MonitorId};

use crate::entities::Check;

pub type RepoResult<T> = Result<T, Box<dyn Error + Send + Sync>>;

#[async_trait]
pub trait CheckRepository: Send + Sync {
    async fn save(&self, check: &Check) -> RepoResult<()>;

    async fn find_by_id(&self, id: CheckId) -> RepoResult<Option<Check>>;

    async fn list_by_monitor(&self, monitor_id: MonitorId) -> RepoResult<Vec<Check>>;

    async fn list_checks(&self, limit: u32, offset: u32) -> RepoResult<Vec<Check>>;

    async fn delete_by_monitor(&self, monitor_id: MonitorId) -> RepoResult<u64>;
}
